﻿using ECommerce.Domain.Common.Specifications;
using ECommerce.Domain.Entities;

namespace ECommerce.Domain.Brands.Specifications;

public sealed class BrandByIdSpecification : BaseSpecification<ProductBrand>
{
    public BrandByIdSpecification(Guid id)
    {
        AddCriteria(b => b.Id == id);
    }
}