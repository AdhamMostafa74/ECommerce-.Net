﻿using ECommerce.Domain.Common.Specifications;
using ECommerce.Domain.Entities;

namespace ECommerce.Domain.Brands.Specifications;

public sealed class BrandsSpecification : BaseSpecification<ProductBrand>
{
    public BrandsSpecification()
    {
        ApplyOrderBy(b => b.Name);
    }
}