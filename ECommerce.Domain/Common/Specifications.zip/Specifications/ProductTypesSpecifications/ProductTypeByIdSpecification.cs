﻿using ECommerce.Domain.Common.Specifications;
using ECommerce.Domain.Entities;

namespace ECommerce.Domain.ProductTypes.Specifications;

public sealed class ProductTypeByIdSpecification : BaseSpecification<ProductType>
{
    public ProductTypeByIdSpecification(Guid id)
    {
        AddCriteria(t => t.Id == id);
    }
}