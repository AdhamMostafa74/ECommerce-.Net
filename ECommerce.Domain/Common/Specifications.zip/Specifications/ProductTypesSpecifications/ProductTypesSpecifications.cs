﻿using ECommerce.Domain.Common.Specifications;
using ECommerce.Domain.Entities;

namespace ECommerce.Domain.ProductTypes.Specifications;

public sealed class ProductTypesSpecification : BaseSpecification<ProductType>
{
    public ProductTypesSpecification()
    {
        ApplyOrderBy(t => t.Name);
    }
}