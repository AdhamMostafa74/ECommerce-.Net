﻿namespace ECommerce.Domain.Products.Specifications;

public sealed class ProductSpecificationParameters
{
    public Guid? BrandId { get; init; }

    public Guid? ProductTypeId { get; init; }

    public string? Search { get; init; }

    public decimal? MinPrice { get; init; }

    public decimal? MaxPrice { get; init; }

    public string? Sort { get; init; }

    public int PageNumber { get; init; } = 1;

    public int PageSize { get; init; } = 10;
}