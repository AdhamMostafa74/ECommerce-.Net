﻿using ECommerce.Domain.Entities;
using ECommerce.Domain.Products.Specifications;

namespace ECommerce.Domain.Common.Specifications.ProductsSpecifications;

public sealed class ProductsSpecification : BaseSpecification<Product>
{
    public ProductsSpecification(ProductSpecificationParameters parameters)
    {
        AddInclude(p => p.ProductBrand);
        AddInclude(p => p.ProductType);

        if (parameters.BrandId.HasValue)
        {
            AddCriteria(p => p.ProductBrandId == parameters.BrandId.Value);
        }

        if (parameters.ProductTypeId.HasValue)
        {
            AddCriteria(p => p.ProductTypeId == parameters.ProductTypeId.Value);
        }

        if (!string.IsNullOrWhiteSpace(parameters.Search))
        {
            var search = parameters.Search.Trim().ToLower();

            AddCriteria(p => p.Name.Contains(search, StringComparison.CurrentCultureIgnoreCase));
        }

        if (parameters.MinPrice.HasValue)
        {
            AddCriteria(p => p.Price >= parameters.MinPrice.Value);
        }

        if (parameters.MaxPrice.HasValue)
        {
            AddCriteria(p => p.Price <= parameters.MaxPrice.Value);
        }

        switch (parameters.Sort?.ToLower())
        {
            case "priceasc":
                ApplyOrderBy(p => p.Price);
                break;

            case "pricedesc":
                ApplyOrderByDescending(p => p.Price);
                break;

            case "name":
                ApplyOrderBy(p => p.Name);
                break;

            default:
                ApplyOrderBy(p => p.Name);
                break;
        }

        ApplyPaging(
            (parameters.PageNumber - 1) * parameters.PageSize,
            parameters.PageSize);
    }
}