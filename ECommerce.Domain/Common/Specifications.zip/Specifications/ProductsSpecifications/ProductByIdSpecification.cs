﻿using ECommerce.Domain.Common.Specifications;
using ECommerce.Domain.Entities;

namespace ECommerce.Domain.Products.Specifications;

public sealed class ProductByIdSpecification : BaseSpecification<Product>
{
    public ProductByIdSpecification(Guid id)
    {
        AddCriteria(p => p.Id == id);

        AddInclude(p => p.ProductBrand);

        AddInclude(p => p.ProductType);
    }
}