﻿using ECommerce.Domain.Entities;
using ECommerce.Domain.Products.Specifications;

namespace ECommerce.Domain.Common.Specifications.ProductsSpecifications;

public sealed class ProductsCountSpecification : BaseSpecification<Product>
{
    public ProductsCountSpecification(ProductSpecificationParameters parameters)
    {
        if (parameters.BrandId.HasValue)
        {
            AddCriteria(p => p.ProductBrandId == parameters.BrandId.Value);
        }

        if (parameters.ProductTypeId.HasValue)
        {
            AddCriteria(p => p.ProductTypeId == parameters.ProductTypeId.Value);
        }

        if (!string.IsNullOrWhiteSpace(parameters.Search))
        {
            var search = parameters.Search.Trim().ToLower();

            AddCriteria(p => p.Name.Contains(search, StringComparison.CurrentCultureIgnoreCase));
        }

        if (parameters.MinPrice.HasValue)
        {
            AddCriteria(p => p.Price >= parameters.MinPrice.Value);
        }

        if (parameters.MaxPrice.HasValue)
        {
            AddCriteria(p => p.Price <= parameters.MaxPrice.Value);
        }
    }
}